SunSpring sandbox certification RQ/RS
Environment: https://sandbox.sunspring.ae
Generated: 2026-08-20 13:22:14

Route discovery: FlightSchedule (from_date / to_date)
Booking route used: IKA-MCT

Flow per scenario:
FlightSearch → AirPrice → Book → Confirm → AirDemandTicket → Cancel

00-flight-schedule — active routes
01 — one adult (one way)
02 — one adult + one child (one way)
03 — two adults + one child + one infant (one way)
04 — two adults (round trip)

Authorize token / passwords are not included.